import { useDispatch, useSelector } from "react-redux";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { setSelectedUser } from "@/redux/authSlice";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { MessageCircleCode } from "lucide-react";
import Messages from "./Messages";
import { useEffect, useRef, useState } from "react";
import { sendMessage } from "@/services/messageService";
import { setMessages } from "@/redux/chatSlice";
import { setGetConversation } from '@/redux/authSlice'

const ChatPage = () => {
	const [textMessage, setTextMessage] = useState("")
	const { user, selectedUser, getConversation } = useSelector(store => store.auth);
	const { onlineUsers, messages } = useSelector(store => store.chat)
	const [isSending, setIsSending] = useState(false);
	const dispatch = useDispatch()
	const inputRef = useRef(null); // Thêm useRef

	useEffect(() => {
		if (selectedUser && inputRef.current) {
			inputRef.current.focus(); // Tự động focus vào input khi chọn user
		}
	}, [selectedUser]);

	const sendMessageHandler = async (receiverId) => {
		try {
			const res = await sendMessage(receiverId, { textMessage })
			if (res.success) {
				dispatch(setMessages([...messages, res.newMessage]))

				// Cập nhật hội thoại mới nhất lên đầu Redux store
				const updatedConversations = getConversation.map(conv => {
					if (conv._id === receiverId) {
						return { ...conv, updatedAt: new Date().toISOString() }; // Giả lập update
					}
					return conv;
				});

				// Sort theo `updatedAt` mới nhất
				updatedConversations.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

				dispatch(setGetConversation(updatedConversations));

				setTextMessage("")
			}
		} catch (error) {
			console.log(error)
		}
	}

	useEffect(() => {
		return () => {
			dispatch(setSelectedUser(null))
		}
	}, [])

	const handleSendMessage = async () => {
		if (isSending || !textMessage.trim()) return;
		setIsSending(true); // Đánh dấu là đang gửi
		await sendMessageHandler(selectedUser?._id);
		setIsSending(false); // Mở lại gửi tin nhắn
	};

	return (
		<div className="flex ml-[16%] h-screen">
			<section className="w-full md:w-1/4 my-8" >
				<h1 className="font-bold mb-4 px-3 text-xl">{user?.username}</h1>
				<hr className="mb-4 border-gray-300" />
				<div className="overflow-y-auto h-[80vh]" >
					{
						getConversation.map((suggestedUser) => {
							const isOnline = onlineUsers.includes(suggestedUser?._id)
							return (
								<div onClick={() => dispatch(setSelectedUser(suggestedUser))} className="flex gap-3 items-center p-3 hover:bg-gray-50 cursor-pointer" key={suggestedUser?._id} >
									<Avatar className="w-14 h-14" >
										<AvatarImage src={suggestedUser?.profilePicture} />
										<AvatarFallback>CN</AvatarFallback>
									</Avatar>
									<div className="flex flex-col" >
										<span className="font-medium" >{suggestedUser?.username}</span>
										<span className={`text-xs font-bold ${isOnline ? "text-green-600" : "text-red-600"}`}>{isOnline ? "online" : "offline"}</span>
									</div>
								</div>
							)
						})
					}
				</div>

			</section>
			{
				selectedUser ? (
					<section className="flex-1 border-l border-l-gray-300 flex flex-col h-full">
						<div className="flex gap-3 items-center px-3 py-2 border-b border-gray-300 sticky top-0 bg-white z-10">
							<Avatar>
								<AvatarImage src={selectedUser?.profilePicture} alt="profile" />
								<AvatarFallback>CN</AvatarFallback>
							</Avatar>
							<div className="flex flex-col">
								<span>{selectedUser?.username}</span>
							</div>
						</div>
						<Messages selectedUser={selectedUser} />
						<div className="flex items-center p-4 border-t border-t-gray-300">
							<Input
								ref={inputRef}  // Gán ref vào input
								value={textMessage}
								onChange={(e) => setTextMessage(e.target.value)} type="text" className="flex-1 mr-2 focus-visible:ring-transparent" placeholder="Message..."
								onKeyDown={(e) => {
									if (e.key === 'Enter') {
										handleSendMessage();
									}
								}} />
							<Button onClick={() => sendMessageHandler(selectedUser?._id)} type="submit" >  Send</Button>
						</div>
					</section>
				) : (
					<div className="flex flex-col items-center justify-center mx-auto">
						<MessageCircleCode className="w-32 h-32 my-4" />
						<h1 className="font-medium text-xl">Your messages</h1>
						<span>Send a message to start chat</span>
					</div>
				)
			}
		</div>
	)
}

export default ChatPage
