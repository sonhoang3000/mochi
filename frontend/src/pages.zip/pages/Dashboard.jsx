import axios from 'axios';
import { ArcElement, BarElement, CategoryScale, Chart as ChartJS, Legend, LinearScale, Title, Tooltip } from 'chart.js';
import { useEffect, useState } from 'react';
import { Bar, Pie } from 'react-chartjs-2';
import Sidebar from './Sidebar';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const Dashboard = () => {
  const [userCount, setUserCount] = useState(0);
  const [postCount, setPostCount] = useState(0);
  const [onlineUsers, setOnlineUsers] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [pieData, setPieData] = useState({});
  const [barData, setBarData] = useState({});

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://localhost:8000/admin/dashboard');
        setUserCount(response.data.totalUsers);
        setPostCount(response.data.totalPosts);
        setOnlineUsers(response.data.onlineUsers);

        setPieData({
          labels: ['Users', 'Posts', 'Online Users'],
          datasets: [{
            data: [response.data.totalUsers, response.data.totalPosts, response.data.onlineUsers],
            backgroundColor: ['#36A2EB', '#FF6384', '#FFCD56'],
            hoverBackgroundColor: ['#36A2EB', '#FF6384', '#FFCD56'],
          }]
        });
        setBarData({
          labels: ['Users', 'Posts', 'Online Users'],
          datasets: [{
            label: 'Count',
            data: [response.data.totalUsers, response.data.totalPosts, response.data.onlineUsers],
            backgroundColor: '#4CAF50',
          }]
        });

      } catch (error) {
        setError(`An error occurred: ${error.message}`);
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar />
      <div className="p-6 w-full">

        {error && <div className="text-red-500 mb-4 text-lg">{error}</div>}

        {loading ? (
          <div className="text-center text-lg text-gray-600">Loading...</div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="p-6 bg-white rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4 text-gray-700">Pie Chart</h3>
              <Pie data={pieData} />
            </div>

            <div className="p-6 bg-white rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4 text-gray-700">Bar Chart</h3>
              <Bar data={barData} />
            </div>

            <div className="col-span-1 lg:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-blue-500 text-white rounded-lg shadow-md text-center">
                <h3 className="text-xl font-medium">Total Users</h3>
                <p className="text-4xl font-bold mt-2">{userCount}</p>
              </div>
              <div className="p-6 bg-green-500 text-white rounded-lg shadow-md text-center">
                <h3 className="text-xl font-medium">Total Posts</h3>
                <p className="text-4xl font-bold mt-2">{postCount}</p>
              </div>
              <div className="p-6 bg-yellow-500 text-white rounded-lg shadow-md text-center">
                <h3 className="text-xl font-medium">Online Users</h3>
                <p className="text-4xl font-bold mt-2">{onlineUsers}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
