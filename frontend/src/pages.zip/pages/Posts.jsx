import axios from 'axios';
import { useEffect, useState } from 'react';
import Sidebar from './Sidebar';

const AdminPosts = () => {
  const [posts, setPosts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = (search = "") => {
    setLoading(true);
    axios.get('http://localhost:8000/admin/posts', { params: { search } })
      .then(response => {
        console.log(response.data);
        setPosts(response.data);
        setError("");
      })
      .catch(error => {
        console.error('Error fetching posts:', error);
        setError("Có lỗi xảy ra khi tải bài viết.");
      })
      .finally(() => setLoading(false));
  };

  const handleSearch = () => {
    fetchPosts(searchTerm);
  };

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar />

      <div className="p-6 w-full">
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Quản lý Bài Viết</h2>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-white p-4 shadow-md rounded-lg mb-6">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
            placeholder="Tìm kiếm bài viết..."
          />
          <button
            onClick={handleSearch}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
          >
            Tìm kiếm
          </button>
        </div>

        {error && <div className="text-red-500 mb-4">{error}</div>}

        <div className="overflow-x-auto bg-white shadow-md rounded-lg">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-blue-500 text-white">
                <th className="p-3 border">ID</th>
                <th className="p-3 border">Caption</th>
                <th className="p-3 border">Hình ảnh</th>
                <th className="p-3 border">Tác giả</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="4" className="text-center p-4">Đang tải...</td>
                </tr>
              ) : (
                posts.length > 0 ? (
                  posts.map(post => (
                    <tr key={post._id} className="border-t hover:bg-gray-100 transition">
                      <td className="p-3 border text-center">{post._id}</td>
                      <td className="p-3 border">{post.caption}</td>
                      <td className="p-3 border flex justify-center">
                        <img src={post.src} alt={post.caption} className="w-20 h-20 object-cover rounded" />
                      </td>
                      <td className="p-3 border text-center">
                        {post.author ? post.author.username : 'Không có tác giả'}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="text-center p-4">Không có dữ liệu</td>
                  </tr>
                )
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminPosts;